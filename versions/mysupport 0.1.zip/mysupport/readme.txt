Name: MySupport
Description: Add features to your forum to help with giving support. Allows you to mark a thread as solved or technical, assign threads to users, give threads priorities, mark a post as the best answer in a thread, and more to help you run a support forum.
Website: http://mattrogowski.co.uk
Author: MattRogowski
Authorsite: http://mattrogowski.co.uk
Version: 0.1
Compatibility: 1.6.x
Files: 4 (plus 13 images)
Templates added: 21
Template changes: 20
Settings added: 25
Database changes: 1 new table, 21 new columns to 4 default tables.

To Install:
Upload ./inc/plugins/mysupport.php to ./inc/plugins/
Upload ./inc/languages/english/mysupport.lang.php to ./inc/languages/english/
Upload ./inc/languages/english/admin/config_mysupport.lang.php to ./inc/languages/english/admin/
Upload ./admin/modules/config/mysupport.php to ./admin/modules/config/
Open ./files/mysupport_css_additions.css and add the code inside to the bottom of global.css for your themes, by going to ACP > Templates & Style > **choose theme** > Edit Stylesheet: Advanced Mode > scroll down and add the CSS to the bottom.
Go to ACP > Templates & Style > Templates > **expand template set** > User Control Panel Templates > usercp_options > find:
	<br />
	<fieldset class="trow2">
	<legend><strong>{$lang->other_options}</strong></legend>
change to:
	<br />
	{$mysupport_usercp_options}
	<fieldset class="trow2">
	<legend><strong>{$lang->other_options}</strong></legend>
Go to ACP > Plugins > Install and Activate
Go to ACP > Configuration > MySupport Settings > Configure Settings.
Go to ACP > Configuration MySupport (left menu) > setup where MySupport can be used and who can use it.

Information:
This plugin will add multiple support features to your forum.

* Choose which forums to enable MySupport in.
* Mark threads as solved.
* Mark threads as technical.
 ** Alert of technical threads in header.
 ** List of technical threads in Mod CP.
 ** Option to hide a technical status from people who can't mark as technical; display technical threads as simply not solved to regular users.
* Display the status of threads as either an image, or as text. Configurable on a per-user basis as well as a global basis.
* Assign threads.
 ** Alert of assigned threads in header.
 ** List of assigned threads in User CP.
 ** Icon on forum display to see what threads have been assigned and what threads are assigned to you.
 ** PM/subscribe to thread when assigned.
* Give threads priorities.
 ** Highlighted on forum display in colour representing priority.
* Mark the best answer in the thread.
 ** Only thread author able to do this.
 ** Highlights the best answer and includes quick access link to jump straight to best answer, both at the top of the thread and on the forum display.
* List of users' support threads in User CP.
* Highlight staff responses.
* Deny users support.
 ** Configurable reasons.
 ** Unable to make threads in MySupport forum.
* Configure a points system to receive points for MySupport actions.
 ** Receive points for having a post marked as the best answer.

Change Log:
01/09/10 - v0.1 -> Initial beta release.

Copyright 2010 Matthew Rogowski

 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at

 ** http://www.apache.org/licenses/LICENSE-2.0

 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.